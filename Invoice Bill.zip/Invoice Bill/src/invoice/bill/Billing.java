/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package invoice.bill;

/**
 *
 * @author Abel
 */
public class Billing {
    private double quantity;
    private double price;
    
    public Billing(){
        quantity = 5;
        price =25.0;
    }
    
    
    public Billing(double quantity, double price){
        this.quantity = quantity;
        this.price = price;
    }
    
    public double computeBill(double price){
        double total = price * quantity;
        double tax = total * 0.08;
        return total + tax;
    }
    
    public double computeBill(double price, double quantity){
        double total = price * quantity;
        double tax = total * 0.08;
        return total + tax;
    }
    
    public double computeBill(double price, double quantity, double cuponValue){
        double total = (price * quantity) - cuponValue;
        double tax = total * 0.08;
        return total + tax;
    }
}
