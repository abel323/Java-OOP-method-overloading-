/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package invoice.bill;

/**
 *
 * @author Abel
 */
public class InvoiceBill {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double price = 30.50;
        double quantity = 3;
        double cuponValue = 4;
        Billing b = new Billing();
        
        System.out.println("bill1="+b.computeBill(price));
        System.out.println("bill2="+b.computeBill(price, quantity));
        System.out.println("bill3="+b.computeBill(price, quantity, cuponValue));
    }
    
}
